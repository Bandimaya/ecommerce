import { useToast, toast } from "@/hooks/useToast";

export { useToast, toast };
