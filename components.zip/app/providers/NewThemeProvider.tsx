// This file is intentionally left blank as it has been deprecated.
// The functionality has been moved to contexts/ThemeContext.tsx